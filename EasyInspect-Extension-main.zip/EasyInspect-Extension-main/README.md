# EasyInspect-Extension
Ever wish you were a master coder that could change what a website looks like in a matter of seconds? With EasyInspect, you can do exactly that! Resize, edit text, change color, move objects, and much, much more!
